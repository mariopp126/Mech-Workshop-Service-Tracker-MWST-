﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MWST_API
{
    public class RQRS
    {
        public string Request { get; set; }
        public string Respone { get; set; }

        // Probably not needed
    }
}
