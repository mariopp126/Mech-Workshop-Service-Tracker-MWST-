using System;
using System.Collections;

namespace enums
{
        public enum Role{
        Customer,
        Mechanic,
        Adviser,
        Admin
    }
}