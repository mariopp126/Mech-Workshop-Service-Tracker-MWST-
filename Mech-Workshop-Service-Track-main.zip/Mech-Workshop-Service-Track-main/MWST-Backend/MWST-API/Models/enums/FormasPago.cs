using System;
using System.Collections;

namespace enums
{
    public enum FormasPago {
         Debito,
         Credito       
    }
}
    /*
    Tipos de pagos
    Pago cliente
        Contado,
        Credito,
        Seguro
    Garantia
    Interno
    */