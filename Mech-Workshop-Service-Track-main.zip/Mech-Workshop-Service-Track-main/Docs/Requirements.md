# Requirements

https://docs.google.com/document/d/1tQdkqDEShxlVcYMFSYa9fwoLkoh51u5x/edit

* Status Notifications
* Status Summary
* Completion bar
* Login user
  * Forgot password
  * Change password
* Register user
* Calendar/Date schedule
* Menu of (available) Services
* Situation Notifications
* User History
* Service Selection
* Service Evaluation
* Register Vehicle
* Request an emergency status
* Online Payment
